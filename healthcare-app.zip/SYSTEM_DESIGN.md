# Healthcare Appointment & Follow-up Manager - System Design

## 1. Double-Booking Prevention

Preventing double bookings in a healthcare appointment system requires robust concurrency control, especially when multiple patients might attempt to book the exact same slot for the same doctor simultaneously.

**Database-level Enforcement:**
The primary defense against double booking lies in the database layer. In a full production environment running PostgreSQL, the `bookAppointment` service uses a database transaction combined with row-level locks or serializable transaction isolation. The transaction begins by checking for any overlapping appointments (`status = 'BOOKED'`) for the specific `doctorId` within the requested time range. If an overlap is detected, the transaction aborts. 

If no overlap exists, the transaction creates the new appointment. Because this entire sequence (check -> create) is wrapped in an atomic transaction, race conditions are mitigated. In the current SQLite fallback implementation, Prisma achieves this by locking the local database file during writes, ensuring that two concurrent booking requests for the same slot are evaluated sequentially.

## 2. Slot Hold Mechanism

Before a patient officially confirms an appointment, they must fill out a comprehensive symptom form. This form can take several minutes to complete, during which the slot must be temporarily reserved to ensure it isn’t snatched by another patient.

**In-Memory / Redis Cache Hold:**
The system uses a highly available, TTL-based cache (like Redis, mocked via an in-memory map in this project) to implement the slot hold mechanism. 
1. When a patient selects a slot, the system generates a unique key (e.g., `doctor123_2026-08-20T09:00:00Z`).
2. This key is stored in the cache with a Time-To-Live (TTL) of 5 minutes, mapping to the specific `patientId`.
3. If another patient attempts to click that slot, the system checks the cache. Since the key exists and belongs to someone else, the system temporarily grays out the slot on the frontend and rejects API requests.
4. If the first patient abandons the symptom form, the 5-minute TTL expires automatically, freeing up the slot without requiring any database cleanup or manual intervention.
5. If the first patient completes the form and submits the booking, the transaction commits the appointment to the persistent database and manually invalidates the cache key.

## 3. Doctor Leave Conflict Handling

Doctors may have unexpected emergencies or require sudden leaves. When an admin marks a doctor as "on leave" for a specific date, the system must handle existing bookings gracefully.

**Conflict Resolution Strategy:**
The admin dashboard contains a "Manage Leaves" portal. When a leave is registered for a specific date:
1. The backend inserts a record into the `DoctorLeave` table.
2. The system queries the `Appointment` table for all `BOOKED` appointments belonging to that doctor on the specified date.
3. In a transaction, the status of these overlapping appointments is immediately updated to `CANCELLED`.
4. Crucially, the system enqueues a batch of jobs to the notification queue (BullMQ). This ensures that every affected patient receives an immediate email notification about the cancellation, advising them to re-book. 
5. Simultaneously, the system triggers the Google Calendar API to delete or mark the corresponding calendar events as cancelled.

Furthermore, the booking API checks the `DoctorLeave` table before confirming any *new* appointments. If a patient tries to book a slot on a date where the doctor is marked as on leave, the transaction throws an exception.

## 4. Notification Failure Handling

Healthcare reminders and cancellation notices are highly sensitive; failures in email delivery cannot silently drop critical information.

**Asynchronous Message Queue (BullMQ):**
Sending emails directly within the API request lifecycle is dangerous. If the SMTP server (e.g., SendGrid or Nodemailer) times out, the user's API request fails. Instead, the platform offloads all email notifications to a robust background queue powered by BullMQ and Redis.

**Reliability Features:**
1. **Decoupling**: When a patient books an appointment, the API merely *enqueues* a job representing the confirmation email and immediately returns a success response to the user.
2. **Automatic Retries & Exponential Backoff**: The email worker processes jobs from the queue. If an email fails to send due to a temporary network issue or a rate limit on the SMTP provider, BullMQ catches the exception. The job is marked for retry using an exponential backoff strategy (e.g., retry in 5s, then 25s, then 125s) up to 3 times.
3. **Dead Letter Queue (DLQ)**: If all retries fail (e.g., invalid email address hard bounce), the job is moved to a "failed" state (DLQ). System administrators can monitor this queue and manually intervene if necessary, ensuring no critical communication is lost permanently.
4. **Cron Job Resiliency**: The medication reminder system runs via a `node-cron` schedule every hour. It queries the database for reminders where `nextReminderTime <= NOW()`. Upon enqueueing the reminder email, it updates the database timestamp. If the cron job itself crashes midway, the transaction rollback ensures it will simply pick up the unsent reminders on the next hourly tick.
