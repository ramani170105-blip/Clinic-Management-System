# Healthcare Appointment & Follow-up Manager

A comprehensive healthcare appointment platform with separate portals for patients, doctors, and administrators, featuring AI-generated summaries and calendar integrations.

## Prerequisites
- Node.js v18+
- npm or yarn

*(Note: This project is configured to use SQLite out-of-the-box for seamless local evaluation without needing Docker or Redis installations. In production, switch to PostgreSQL and enable the Redis connection in BullMQ workers.)*

## Setup Guide

### 1. Backend Setup
1. Open terminal and navigate to the backend directory:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Copy the `.env.example` to `.env` (it is pre-configured for local sqlite):
   ```bash
   cp .env.example .env
   ```
   *Note: Make sure to add your Google Gemini API key to `GOOGLE_API_KEY` in the `.env` file.*

4. Setup the database (SQLite):
   ```bash
   npx prisma generate
   npx prisma db push
   ```
5. Start the backend server:
   ```bash
   npm run dev
   ```
   *(Ensure you have a `dev` script in your backend package.json, e.g., `"dev": "ts-node src/index.ts"` or `"nodemon src/index.ts"`)*

### 2. Frontend Setup
1. Open a new terminal and navigate to the frontend directory:
   ```bash
   cd frontend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the Vite development server:
   ```bash
   npm run dev
   ```
4. Access the web application at `http://localhost:5173`.

## Database Schema (Prisma)
- **User**: Base table for authentication, holds `email`, `passwordHash`, and `role` (ADMIN, DOCTOR, PATIENT).
- **PatientProfile / DoctorProfile**: Extended profiles for users containing role-specific details (e.g., specialisation, phone).
- **DoctorLeave**: Tracks dates when a doctor is unavailable.
- **Appointment**: Core table tracking slots (`startTime`, `endTime`), patient, doctor, and status.
- **PreVisitForm**: Symptom details filled by the patient, including LLM analysis outputs (Urgency, Chief Complaint, Suggested Questions).
- **PostVisitNote**: Doctor's clinical notes, including LLM-generated patient-friendly summaries and prescriptions.
- **MedicationReminder**: Tracks reminders, frequency, and next execution time for background cron jobs.

*(See `backend/prisma/schema.prisma` for the full schema definitions.)*

## LLM Prompts Used
**Pre-Visit Summary (Gemini 2.5 Flash):**
> "Analyse these symptoms and return a JSON object with the following keys exactly (no markdown wrapping): 'urgencyLevel' (Low / Medium / High), 'chiefComplaint' (string), and 'suggestedQuestions' (array of 3 strings). Symptoms: [USER_INPUT]"

**Post-Visit Summary (Gemini 2.5 Flash):**
> "Convert these clinical notes into a patient-friendly summary with medication schedule and follow-up steps. Return a JSON object with exactly these keys: 'patientSummary' (string), 'medicationSchedule' (string), 'followUpSteps' (string). Notes: [CLINICAL_NOTES]"

## Google Calendar Setup
1. Go to the [Google Cloud Console](https://console.cloud.google.com/).
2. Create a new project and navigate to **APIs & Services > Library**. Enable the **Google Calendar API**.
3. Go to **Credentials** and click **Create Credentials > OAuth client ID**.
4. Set application type to **Web application**.
5. Under Authorized redirect URIs, add: `http://localhost:3000/api/webhook/google-calendar/callback`
6. Copy the `Client ID` and `Client Secret` and place them in the backend `.env` file (`GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET`).

## API Documentation (Selected Endpoints)
- `POST /api/auth/register`: Register a new user (Patient, Doctor, Admin).
- `POST /api/auth/login`: Authenticate and receive a JWT.
- `GET /api/patient/doctors`: List all doctors.
- `GET /api/patient/appointments`: List appointments for the logged-in patient.
- `POST /api/admin/doctors/leave`: Admin endpoint to mark a doctor on leave.
- `GET /api/doctor/appointments`: List appointments for the logged-in doctor.
