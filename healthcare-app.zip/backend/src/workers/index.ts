import { Worker } from 'bullmq';
import { sendEmail } from '../services/email';
import { prisma } from '../index';
import { enqueueEmail } from '../services/email';
import cron from 'node-cron';

export const startWorkers = () => {
  // 1. Email Worker
  const emailWorker = new Worker(
    'emailQueue',
    async (job) => {
      const { to, subject, text } = job.data;
      await sendEmail(to, subject, text);
    },
    {
      connection: {
        host: process.env.REDIS_HOST || 'localhost',
        port: parseInt(process.env.REDIS_PORT || '6379'),
      },
    }
  );

  emailWorker.on('completed', (job) => {
    console.log(`Email job ${job.id} completed successfully`);
  });

  emailWorker.on('failed', (job, err) => {
    console.error(`Email job ${job?.id} failed with ${err.message}`);
  });

  // 2. Cron Job for Medication Reminders
  // Runs every hour to check for due medication reminders
  cron.schedule('0 * * * *', async () => {
    console.log('Running medication reminder cron job...');
    try {
      const now = new Date();
      
      const dueReminders = await prisma.medicationReminder.findMany({
        where: {
          active: true,
          nextReminderTime: { lte: now },
        },
        include: { patient: { include: { user: true } } },
      });

      for (const reminder of dueReminders) {
        // Enqueue email
        await enqueueEmail(
          reminder.patient.user.email,
          'Medication Reminder',
          `Hello ${reminder.patient.name}, it's time to take your medication: ${reminder.medicationName}.`
        );

        // Update next reminder time
        const nextTime = new Date(reminder.nextReminderTime);
        nextTime.setHours(nextTime.getHours() + reminder.frequencyHours);

        await prisma.medicationReminder.update({
          where: { id: reminder.id },
          data: { nextReminderTime: nextTime },
        });
      }
    } catch (error) {
      console.error('Error in medication reminder cron job:', error);
    }
  });

  console.log('Workers and cron jobs started.');
};
