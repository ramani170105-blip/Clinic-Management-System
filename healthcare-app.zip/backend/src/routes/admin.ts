import { Router, Request, Response } from 'express';
import { authenticate, requireRole } from '../middleware/auth';
import { prisma } from '../index';

const router = Router();

router.use(authenticate);
router.use(requireRole(['ADMIN']));

router.post('/doctors/leave', async (req: Request, res: Response): Promise<void> => {
  const { doctorId, date } = req.body;
  try {
    // Basic implementation placeholder
    const leave = await prisma.doctorLeave.create({
      data: {
        doctorId,
        date: new Date(date),
      },
    });
    res.json(leave);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
