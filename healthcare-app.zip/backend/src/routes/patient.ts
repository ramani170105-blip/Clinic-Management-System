import { Router, Request, Response } from 'express';
import { authenticate, requireRole } from '../middleware/auth';
import { prisma } from '../index';

const router = Router();

router.get('/doctors', async (req: Request, res: Response) => {
  try {
    const doctors = await prisma.doctorProfile.findMany({
      include: { user: { select: { email: true } } },
    });
    res.json(doctors);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.use(authenticate);
router.use(requireRole(['PATIENT']));

router.get('/appointments', async (req: any, res: Response) => {
  try {
    const patient = await prisma.patientProfile.findUnique({ where: { userId: req.user.id } });
    if (!patient) return res.status(404).json({ error: 'Patient profile not found' });

    const appointments = await prisma.appointment.findMany({
      where: { patientId: patient.id },
      include: { doctor: true, preVisitForm: true, postVisitNote: true },
    });
    res.json(appointments);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
