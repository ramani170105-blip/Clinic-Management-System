import { GoogleGenAI } from '@google/genai';

const ai = new GoogleGenAI({ apiKey: process.env.GOOGLE_API_KEY });

export const generatePreVisitSummary = async (symptoms: string) => {
  try {
    const prompt = `Analyse these symptoms and return a JSON object with the following keys exactly (no markdown wrapping): 
    "urgencyLevel" (Low / Medium / High), "chiefComplaint" (string), and "suggestedQuestions" (array of 3 strings). 
    Symptoms: ${symptoms}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = response.text || "{}";
    
    // Attempt to parse JSON safely
    const cleanText = text.replace(/```json\n|\n```|```/g, '').trim();
    const result = JSON.parse(cleanText);

    return {
      urgencyLevel: result.urgencyLevel || 'Medium',
      chiefComplaint: result.chiefComplaint || 'Unknown',
      suggestedQuestions: result.suggestedQuestions?.join(' | ') || '',
    };
  } catch (error) {
    console.error('LLM Pre-Visit Summary failed', error);
    // Graceful fallback
    return {
      urgencyLevel: 'Medium',
      chiefComplaint: 'Fallback triggered, parsing failed',
      suggestedQuestions: 'What is the exact timeline of these symptoms? | Any previous medical history related to this? | Are you taking any medications?',
    };
  }
};

export const generatePostVisitSummary = async (clinicalNotes: string) => {
  try {
    const prompt = `Convert these clinical notes into a patient-friendly summary with medication schedule and follow-up steps. Return a JSON object with exactly these keys:
    "patientSummary" (string), "medicationSchedule" (string), "followUpSteps" (string).
    Notes: ${clinicalNotes}`;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });
    
    const text = response.text || "{}";
    const cleanText = text.replace(/```json\n|\n```|```/g, '').trim();
    const result = JSON.parse(cleanText);

    return {
      patientSummary: result.patientSummary || '',
      medicationSchedule: result.medicationSchedule || '',
      followUpSteps: result.followUpSteps || '',
    };
  } catch (error) {
    console.error('LLM Post-Visit Summary failed', error);
    // Graceful fallback
    return {
      patientSummary: 'Please refer to the doctor directly for summary. (AI unavailable)',
      medicationSchedule: 'Follow the prescription paper provided.',
      followUpSteps: 'Please book a follow-up if symptoms persist.',
    };
  }
};
