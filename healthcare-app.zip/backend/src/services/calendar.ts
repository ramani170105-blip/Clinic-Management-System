import { google } from 'googleapis';

const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI
);

// This function generates the URL to consent to Google Calendar access
export const getAuthUrl = () => {
  return oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: ['https://www.googleapis.com/auth/calendar.events'],
  });
};

// Assuming you store tokens in memory/db for the demo
let userTokens: any = null;

export const setTokens = (tokens: any) => {
  userTokens = tokens;
  oauth2Client.setCredentials(tokens);
};

export const createCalendarEvent = async (summary: string, description: string, startTime: Date, endTime: Date) => {
  if (!userTokens) {
    console.warn('Google Calendar tokens not set. Cannot create event.');
    return null;
  }

  const calendar = google.calendar({ version: 'v3', auth: oauth2Client });

  try {
    const event = {
      summary,
      description,
      start: {
        dateTime: startTime.toISOString(),
      },
      end: {
        dateTime: endTime.toISOString(),
      },
    };

    const res = await calendar.events.insert({
      calendarId: 'primary',
      requestBody: event,
    });

    console.log(`Calendar event created: ${res.data.htmlLink}`);
    return res.data.id;
  } catch (error) {
    console.error('Error creating calendar event', error);
    return null;
  }
};
