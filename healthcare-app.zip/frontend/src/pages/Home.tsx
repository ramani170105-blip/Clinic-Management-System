import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div className="flex-center animate-fade-in" style={{ flexDirection: 'column', textAlign: 'center', height: '60vh' }}>
      <h1>Next-Gen Healthcare Appointments</h1>
      <p style={{ color: 'var(--text-secondary)', maxWidth: '600px', marginBottom: '2rem' }}>
        Seamlessly book appointments, get AI-powered symptom analysis, and manage your health follow-ups.
      </p>
      <div style={{ display: 'flex', gap: '1rem' }}>
        <Link to="/register" className="btn btn-primary">Book an Appointment</Link>
        <Link to="/login" className="btn btn-secondary">Doctor Login</Link>
      </div>
    </div>
  );
}
