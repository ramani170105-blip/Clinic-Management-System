import React from 'react';

export default function DoctorDashboard() {
  return (
    <div className="animate-fade-in">
      <h2>Doctor Portal</h2>
      <div className="glass-panel" style={{ marginTop: '2rem' }}>
        <h3>Today's Schedule</h3>
        <p style={{ color: 'var(--text-secondary)' }}>No appointments scheduled for today.</p>
      </div>
    </div>
  );
}
