import React from 'react';

export default function PatientDashboard() {
  return (
    <div className="animate-fade-in">
      <h2>Patient Portal</h2>
      <div className="glass-panel" style={{ marginTop: '2rem' }}>
        <h3>Upcoming Appointments</h3>
        <p style={{ color: 'var(--text-secondary)' }}>You have no upcoming appointments.</p>
        <button className="btn btn-primary" style={{ marginTop: '1rem' }}>Book New Appointment</button>
      </div>
    </div>
  );
}
