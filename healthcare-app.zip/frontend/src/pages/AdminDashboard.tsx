import React from 'react';

export default function AdminDashboard() {
  return (
    <div className="animate-fade-in">
      <h2>Admin Portal</h2>
      <div className="glass-panel" style={{ marginTop: '2rem' }}>
        <h3>Manage Doctors</h3>
        <button className="btn btn-primary">Add Doctor</button>
        <button className="btn btn-secondary" style={{ marginLeft: '1rem' }}>Manage Leaves</button>
      </div>
    </div>
  );
}
